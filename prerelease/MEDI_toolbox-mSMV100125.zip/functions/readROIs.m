function ROIs = readROIs(filename)
labelfile=[filename '.label'];
fid=fopen(labelfile, 'r');
if fid
%     labels = textscan(fid,'%d %d %d %d %d %d %d %s');
    line = textscan(fid,'%s %s',...
        'CommentStyle','#','Delimiter','"');
    fclose(fid);
    labels=line{2};
    idx=[];
    for j=1:length(line{1})
        tmp = textscan(line{1}{j}, '%d');
        idx(j,1)=tmp{1}(1);
    end
    labels=labels(find(idx)); % remove zero index
    idx=idx(find(idx));
else
    error(['Unable to open ' labelfile]);
end
ROIs.idx = idx;
ROIs.label = labels;
niifile=[filename '.nii.gz'];
nii=load_nii_gz(niifile);
ROIs.img = double(nii.img(end:-1:1,end:-1:1,:));
end

