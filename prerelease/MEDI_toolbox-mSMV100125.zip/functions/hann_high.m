function  [out, H] = hann_high(im,voxel_size, fc)
    imf = fftshift(fftn(im));
    H = hann_filter(size(im),voxel_size ,fc);
    H = 1-H;
    out = zeros(size(im));
    outf= imf.*H;
    out=ifftn(fftshift(outf));