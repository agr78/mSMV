% An interal function to parse input arguments for MEDI_L1
%   Created by Tian Liu on 2011.03.16
%   Modified by Tian Liu and Shuai Wang on 2011.03.15
%   Last modified by Tian Liu on 2013.07.24
%   Last modified by Alexandra Roberts on 2023.27.12
%   Last modified by Alexey on 2023.27.12

function [lam, iFreq, RDF, N_std, iMag, Mask, matrix_size, matrix_size0, voxel_size, ...
    delta_TE, CF, B0_dir, merit, smv, radius, data_weighting, gradient_weighting, ... 
    Debug_Mode, lam_CSF, Mask_CSF, opts] = parse_QSM_input(varargin)

merit = 1;
smv = 1;
msmv = 0;
radius = 5;
matrix_size0 = 0;
SS = 0;

opts = struct;
opts.lambda = 1000;
opts.data_weighting = 1;
opts.gradient_weighting = 1;
opts.zeropad = 0;
opts.DEBUG = 'NoDebug';
opts.lambda_CSF = 100;
opts.filename = ['RDF.mat'];
opts.solver='gaussnewton';
opts.percentage = 0.9;
opts.linear = false;    
opts.Lalpha = 100;
opts.Lkappa = 0.1;
opts.Lradius = 1;
opts.Lreg = 0;
opts.cg_verbose = 0;
opts.cg_max_iter = 100;
opts.cg_tol = 0.01;
opts.max_iter = 10;
opts.tol_norm_ratio = 0.1;
opts.regs = struct;
opts.smv_shrink_mask = 1;
opts.resultsdir = fullfile(pwd, 'results');

override = struct;
nargs = size(varargin,2);
if nargs>0
    k = 1;
    fn=fieldnames(opts);
    while k <= nargs
        if strcmpi(varargin{k},'merit')
            merit = 1;
        end
        if strcmpi(varargin{k},'SS')
            SS = 1;
        end
        if strcmpi(varargin{k},'nomerit')
            merit = 0;
        end
        if strcmpi(varargin{k},'smv') || strcmpi(varargin{k},'msmv')
            smv = 1;
            msmv = strcmpi(varargin{k},'msmv');
            if k+1 <= nargs
                radius = varargin{k+1};
                if msmv
                    str = 'mSMV'; 
                else
                    str = 'SMV';
                    msmv = 0;
                end
                fprintf('Using %s with radius %s\n',str,string(radius))
            else
                error('Error getting value for %s', varargin{k});
            end
        end
        if strcmpi(varargin{k},'nosmv')
            smv = 0;
        end
        for j=1:length(fn)
            if strcmpi(varargin{k},fn{j})
                if k+1 <=nargs
                    opts.(fn{j}) = varargin{k+1};
                    override.(fn{j}) = varargin{k+1};
                    k = k + 1;
                else
                    error('Error getting value for %s', varargin{k});
                end
            end
        end
        k = k + 1;
    end
end

lam = opts.lambda;
data_weighting = opts.data_weighting;
gradient_weighting = opts.gradient_weighting;
pad = opts.zeropad;
Debug_Mode = opts.DEBUG;
lam_CSF = opts.lambda_CSF;

load(opts.filename,'iFreq','RDF', 'N_std', 'iMag', 'Mask', 'matrix_size', 'voxel_size', 'delta_TE' ,'CF', 'B0_dir');
opts.matrix_size = matrix_size;
opts.voxel_size = voxel_size;
opts.lam_CSF = lam_CSF;
opts.Mask = Mask;
opts.msmv = msmv;
if msmv
    opts.smv_shrink_mask = 0; 
end
if ~isfield(override, 'tol_norm_ratio')
    if SS
        opts.tol_norm_ratio = 0.01;
    else
        opts.tol_norm_ratio = 0.1;
    end
end

% CSF regularization
opts.Mask_CSF = logical(read_from_mat('Mask_CSF', []));
Mask_CSF = opts.Mask_CSF;

opts.weightS = read_from_mat('weightS', []);

if exist('delta_TE','var') == 0
    delta_TE = input('TE spacing = ');
    save(opts.filename,'delta_TE','-append');
end

if exist('CF','var') == 0
    CF = input('Central Frequency = ');
    save(opts.filename,'CF','-append');
end

if exist('B0_dir','var') == 0
    B0_dir = input('B0 direction = ');
    save(opts.filename,'B0_dir','-append');
end

% Preconditioner
opts.P = read_from_mat('P');
if isempty(opts.P); opts.P = 1; end

% Vessel radius
if ismember('vessel_radius', who('-file', opts.filename))
    opts.vessel_radius = getfield(load(opts.filename, 'vessel_radius'), 'vessel_radius');
else
    opts.vessel_radius = [];
end
% Minimum threshold
if ismember('tmin', who('-file', opts.filename))
    opts.tmin = getfield(load(opts.filename, 'tmin'), 'tmin');
else
    opts.tmin = [];
end
% Number of mSMV iterations
if ismember('maxk', who('-file', opts.filename))
    opts.maxk = getfield(load(opts.filename, 'maxk'), 'maxk');
else
    opts.maxk = [];
end
% Field strength
if ismember('B0_mag', who('-file', opts.filename))
    opts.B0_mag = getfield(load(opts.filename, 'B0_mag'), 'B0_mag');
else
    opts.B0_mag = [];
end
% Prefitler flag
if ismember('prefilter', who('-file', opts.filename))
    opts.prefilter = getfield(load(opts.filename, 'prefilter'), 'prefilter');
else
    opts.prefilter = [];
end

% R2s
opts.R2s = read_from_mat('R2s', []);

% Source seperation parameters and initialization
opts.alpha = read_from_mat('alpha');
opts.beta = read_from_mat('beta');
opts.chi_p_init = read_from_mat('chi_p_init');
opts.chi_n_init = read_from_mat('chi_n_init');

if sum(pad(:))
    matrix_size0 = matrix_size;
    matrix_size = matrix_size + pad;
    iFreq = padarray(iFreq, pad,'post');
    RDF = padarray(RDF, pad,'post');
    N_std = padarray(N_std, pad,'post');
    iMag = padarray(iMag, pad,'post');
    Mask = padarray(Mask, pad,'post');

    % CSF regularization
    if ~isempty(Mask_CSF)
        Mask_CSF = padarray(Mask_CSF, pad,'post');
    end
end

    function y = read_from_mat(varname, defvalue)
        if ismember(varname, who('-file', opts.filename))
            y = getfield(load(opts.filename, varname), varname);
        else
            if nargin>1
                y=defvalue;
            else
                y = 1;
            end
        end
    end

end
