%Gaussian lowpass filter
function  [out, H] = hann_low(im, voxel_size, fc)
    imf = fftshift(fftn(im));
    out = zeros(size(im));
    H = hann_filter(size(im), voxel_size, fc);
    outf= imf.*H;
    out=ifftn(fftshift(outf));
