% This is an implementation of the Morphology Enabled Dipole Inversion (MEDI)
% method for reconstructing a Quantitative Susceptibility Map from MR data.
% The code is not fully optimized and is given for educational purpose.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% USAGE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% To use this tool box, add MEDI_toolbox to your MATLAB Path
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% USAGE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%% EXAMPLE DATASETS %%%%%%%%%%%%%%%%%%%%%%
% Example datasets can be found MEDI_data 
% 01_Numerical_phantom contains the simulation in Neuroimage 2012;59(3):2560-8.
% 02_Wienieff_Liu contains a numerical brain
% 03_Invivo_GE contains a human brain dataset acquired from a GE scanner
% 04_Invivo_Siemens contains a human brain dataset acquired from a Siemens scanner
%%%%%%%%%%%%%%%%%%%%%%%%%% EXAMPLE DATASETS %%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%% NAMING CONVENTION %%%%%%%%%%%%%%%%%%%%%%%%%
%
% high dimensional variable
%
% iField - 4, or 5 dimensional complex MRI dataset. 
%          the 4th dimension is echo 
%          the 5th dimension is channel
%
% 3D variables
%
% Mask - binary mask denoting the region of interest
% iMag - magnitude image, square root of squares of all echoes
% iFreq_raw - the raw field map, which may contain wrapping, 
%             unit in rad/echo
% N_std - estimated noise standard deviation on iFreq_raw
% iFreq - the unwrapped field map, aka total field
%         unit in rad/echo
% RDF - Relative Difference Field, aka local field
%       unit in rad/echo
% R2s - R2* map
% QSM - Quantitative Susceptibility Map, 
%       unit in parts per million, aka ppm
%
% vectors
%
% B0_dir - unit vector representing direction of B0 field 
% matrix_size - sizes ([x y z]) of the imaging volume
% voxel_size - size of the voxel
%              unit in mm
% TE - echo time, unit in sec
%
% scalars
%
% delta_TE - echo spacing, unit in sec
% CF - center frequency, unit in Hz
% B0_strength - magnetic field strength, unit in Tesla
%%%%%%%%%%%%%%%%%%%%%% NAMING CONVENTION %%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%% NECESSARY FUNCTIONS %%%%%%%%%%%%%%%%%%%%%%%%%%
% Adjust the following line to where you've copied MEDI_toolbox
run('PATH\TO\MEDI_toolbox\MEDI_set_path.m');


% Use accelerated (for Siemens and GE only) reading of DICOMs
[iField,voxel_size,matrix_size,CF,delta_TE,TE,B0_dir,files]=Read_DICOM('DICOM_dir');
   
    
% In case of Bruker real/imag data folders:
%
% [iField, CF, B0_dir, Affine3D, TE, delta_TE, matrix_size, voxel_size] = Read_Bruker_DICOM('real_dir','imag_dir');
%
% Other formats may be supported in the future

% Remove echo-to-echo phase inconsistencies in readout phase corected
% complex data
% NOTE: initial testing suggests that use of this function DOES NOT
% introduce negative effects further down the pipeline if normal data
% (i.e., without phase correction) is processed with this function.
%
%[iField] = iField_correction(iField,voxel_size);


% Compute magnitude image
iMag = sqrt(sum(abs(iField).^2,4));

% When using bipolar acquisition, set unipolar to false
unipolar = true;
if unipolar
    % Estimate the frequency offset in each of the voxel using a complex
    % fitting (even echo spacing)
    [iFreq_raw, N_std] = Fit_ppm_complex(iField);
    % Estimate the frequency offset in each of the voxel using a complex
    % fitting (uneven echo spacing)
    % [iFreq_raw N_std] = Fit_ppm_complex_TE(iField,TE);
    
    % Spatial phase unwrapping (region-growing)
    iFreq = unwrapPhase(iMag, iFreq_raw, matrix_size);
else
    % Estimate the frequency offset in each of the voxel using a complex
    % fitting assuming a different phase offset between odd and even 
    % echoes
    [iFreq_raw, N_std] = Fit_ppm_complex_bipolar(iField);
    % Spatial phase unwrapping (region-growing)
    % because of the fitting Fit_ppm_complex_bipolar, 
    % wraps occur at pi, not 2pi. 
    iFreq = unwrapPhase(iMag, iFreq_raw*2, matrix_size)/2;    
end

% Spatial phase unwrapping (graph-cut based)
%
% iFreq = unwrapping_gc(iFreq_raw,iMag,voxel_size);
%
%%%% Simultaneous Phase Unwrapping and Removal of Chemical Shift (SPURS) Using Graph Cuts: Application in Quantitative Susceptibility Mapping
%%%% IEEE TME 20015;34(2):531-540

% if large fringe lines persists, try 
%
% iFreq = unwrapLaplacian((iFreq_raw, matrix_size, voxel_size);
%

% Use FSL BET to extract brain mask
Mask = BET(iMag,matrix_size,voxel_size);

%Prepare mask based on magnitude thresholding
% Mask = genMask(iField,voxel_size);
 
% Background field removasl using Projection onto Dipole Fields
 RDF = PDF(iFreq, N_std, Mask,matrix_size,voxel_size, B0_dir);
%%%% NMR Biomed 2011;24(9):1129-36.
%%%% MRM 2010;63(1):194-206

% Background field removal using Laplacian Boundary Value
% RDF = LBV(iFreq,Mask,matrix_size,voxel_size,0.005);
%%%% NMR Biomed 2014;27(3):312-319

% R2* map needed for ventricular CSF mask
R2s = arlo(TE, abs(iField));

% Ventricular CSF mask for zero referencing 
%	Requirement:
%		R2s:	R2* map
Mask_CSF = extract_CSF(R2s, Mask, voxel_size);

save RDF.mat RDF iFreq iFreq_raw iMag N_std Mask matrix_size...
     voxel_size delta_TE CF B0_dir Mask_CSF;
 
% Morphology enabled dipole inversion with 
% a) zero reference using CSF (MEDI+0)
% b) inclusion of spheric mean value filter in dipole kernel
QSM = MEDI_L1('lambda',1000,'lambda_CSF',100,'merit','smv',5);

% export QSM variable as dicom files in the 'QSM' directory
Write_DICOM(QSM, files, 'QSM')

% Initialization for Source Separation
[chi_p_init,chi_n_init,alpha,beta] = MEDI_L1ss_init(Mask,CF,R2s,QSM,delta_TE);
save RDFss.mat iFreq RDF N_std iMag Mask matrix_size voxel_size delta_TE...
    CF B0_dir alpha beta R2s Mask_CSF chi_p_init chi_n_init

% Source Separation        
X = MEDI_L1ss('lambda',1000, 'smv',5, 'filename', 'RDFss.mat','lambda_CSF',10);
Write_DICOM(X(:,:,:,1), files, 'QSM', 'SeriesDescription', 'Chi_p', ...
    'SeriesNumber', files.SeriesNumber*100+1, 'Window', 0.15, 'Level', 0.075);
Write_DICOM(-X(:,:,:,2), files, 'QSM', 'SeriesDescription', 'Chi_n', ...
    'SeriesNumber', files.SeriesNumber*100+2, 'Window', 0.1, 'Level', 0.05);

% Need to add R2s for mSMV
save RDF.mat R2s -append

% Morphology enabled dipole inversion with 
% a) zero reference using CSF (MEDI+0)
% b) inclusion of spheric mean value filter in dipole kernel
% c) use of mSMV to avoid erosion of the brain mask
QSM_msmv = MEDI_L1('lambda',1000,'lambda_CSF',100,'merit','msmv',5);

% export QSM variable as dicom files in the 'QSM_msmv' directory
Write_DICOM(QSM_msmv, files, 'QSM_msmv')

% Initialization for Source Separation
[chi_p_init,chi_n_init,alpha,beta] = MEDI_L1ss_init(Mask,CF,R2s,QSM_msmv,delta_TE);
save RDFss_msmv.mat iFreq RDF N_std iMag Mask matrix_size voxel_size delta_TE...
    CF B0_dir alpha beta R2s Mask_CSF chi_p_init chi_n_init

% Source Separation        
X_msmv = MEDI_L1ss('lambda',1000, 'msmv',5, 'filename', 'RDFss_msmv.mat','lambda_CSF',10);
Write_DICOM(X_msmv(:,:,:,1), files, 'QSM_msmv', 'SeriesDescription', 'Chi_p', ...
    'SeriesNumber', files.SeriesNumber*100+1, 'Window', 0.15, 'Level', 0.075);
Write_DICOM(-X_msmv(:,:,:,2), files, 'QSM_msmv', 'SeriesDescription', 'Chi_n', ...
    'SeriesNumber', files.SeriesNumber*100+2, 'Window', 0.1, 'Level', 0.05);
