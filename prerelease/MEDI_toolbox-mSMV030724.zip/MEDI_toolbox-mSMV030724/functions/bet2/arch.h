#ifndef ARCH_H_
#define ARCH_H_
#if _MSC_VER < 1800
float roundf(float x);
#endif
#endif
